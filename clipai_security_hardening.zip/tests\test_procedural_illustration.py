import math

from PIL import Image

from youtube_automation.config import PipelineConfig
from youtube_automation.script_writer import Scene
from youtube_automation import procedural_illustration as pi


def _config():
    config = PipelineConfig.load()
    config.video.format = "longform"
    return config


def test_setting_matched_by_keyword():
    scene = Scene(narration="Snow fell over the frozen village.", visual_keywords=["snow", "village"])
    assert pi._setting_for_scene(scene) == "snow"


def test_setting_falls_back_to_default():
    scene = Scene(narration="Something happened one day.", visual_keywords=[])
    assert pi._setting_for_scene(scene) == "default"


def test_headwear_and_outfit_matched_for_royalty():
    scene = Scene(narration="The king collapsed on the throne.", visual_keywords=["king", "crown"])
    assert pi._match(scene, pi._KEYWORD_TO_HEADWEAR) == "crown"
    assert pi._match(scene, pi._KEYWORD_TO_MOOD) == "shocked"


def test_generate_scene_image_writes_a_real_image_file(tmp_path):
    scene = Scene(narration="The scientist stared at the readings in the lab.", visual_keywords=["scientist", "lab"])
    path = pi.generate_scene_image(scene, 0, _config(), tmp_path)
    assert path.exists()
    with Image.open(path) as img:
        assert img.size == tuple(_config().video.resolution_longform)


def test_human_scale_keeps_character_shorter_than_a_house():
    # Regression test: draw_character's raw proportions came out TALLER than
    # a house at the same scale value (~640 units vs a house's ~460), which
    # is exactly the "giant" bug reported against real output - a person
    # towering over their own house. HUMAN_SCALE is applied at the call site
    # (not inside draw_character itself, since fight/crowd scenes tune their
    # own scale separately), so assert on actual rendered bounding boxes
    # rather than trusting the raw constants line up with intent.
    from PIL import ImageChops, ImageDraw
    scale = 1.0
    size = (900, 900)
    ground_y = 800
    white = (255, 255, 255)

    char_img = Image.new("RGB", size, white)
    pi.draw_character(ImageDraw.Draw(char_img), pi.random.Random(0), 450, ground_y, scale * pi.HUMAN_SCALE,
                       (150, 130, 110), None, "neutral")
    char_bbox = ImageChops.difference(char_img, Image.new("RGB", size, white)).getbbox()

    house_img = Image.new("RGB", size, white)
    pi._draw_house(ImageDraw.Draw(house_img), pi.random.Random(0), 450, ground_y, scale)
    house_bbox = ImageChops.difference(house_img, Image.new("RGB", size, white)).getbbox()

    char_height = char_bbox[3] - char_bbox[1]
    house_height = house_bbox[3] - house_bbox[1]
    assert char_height < house_height, (
        f"character ({char_height}px tall) is not shorter than a house ({house_height}px tall) at the same scale"
    )


def test_indoor_scene_renders_a_wall_not_open_sky(tmp_path):
    # Regression test: "indoor" used to draw a house prop standing on grass
    # under an open sky - a literal exterior shot regardless of the setting
    # name - so the top-left corner (pure white "sky") is a direct proxy for
    # whether the room actually reads as an interior.
    scene = Scene(narration="He worked alone in his laboratory late at night.", visual_keywords=["laboratory", "indoor"])
    assert pi._setting_for_scene(scene) == "indoor"
    path = pi.generate_scene_image(scene, 0, _config(), tmp_path)
    with Image.open(path) as img:
        top_left = img.getpixel((5, 5))
    assert top_left != (255, 255, 255), "indoor scene still has blank white sky at the top - not a real interior"


def test_generate_all_produces_one_image_per_scene(tmp_path):
    scenes = [
        Scene(narration="A soldier marched through the ruins.", visual_keywords=["soldier", "ruins"]),
        Scene(narration="Rain fell over the quiet farm.", visual_keywords=["farm", "rain"]),
    ]
    paths = pi.generate_all(scenes, _config(), tmp_path)
    assert len(paths) == 2
    assert all(p.exists() for p in paths)


def test_marine_topic_picks_octopus_subject_and_water_setting():
    scene = Scene(narration="The octopus hides in the reef.", visual_keywords=["octopus", "ocean"])
    assert pi._subject_for_scene(scene) == "octopus"
    assert pi._setting_for_scene(scene) == "water"


def test_dominant_subject_covers_scenes_that_dont_name_it():
    scenes = [
        Scene(narration="The octopus has three hearts.", visual_keywords=["octopus"]),
        Scene(narration="Its blood uses a copper-based protein.", visual_keywords=["blood"]),
    ]
    # The whole-video fallback keeps the subject consistent on the second
    # scene, which never says "octopus".
    assert pi._dominant_subject(scenes) == "octopus"


def test_dominant_subject_ignores_one_incidental_mention_in_a_narrative_video():
    # Regression test: a Norse mythology video (Baldur's death, Loki's
    # punishment, Ragnarok) mentioned Jormungandr - the sea serpent - once,
    # in one scene among many. That single incidental "sea"/"eel"-adjacent
    # mention used to be enough to make "fish" the video's dominant subject,
    # which then got slapped onto unrelated scenes (e.g. Baldur's death by
    # mistletoe) purely by index parity. One mention out of many unrelated
    # scenes must not count as the video being "about" that creature.
    scenes = [
        Scene(narration="Baldur was the most beloved of all the gods.", visual_keywords=["baldur", "god"]),
        Scene(narration="Loki alone knew mistletoe could kill him.", visual_keywords=["mistletoe", "loki"]),
        Scene(narration="Baldur fell dead, pierced by the dart.", visual_keywords=["baldur", "death"]),
        Scene(narration="Loki was bound beneath a venomous serpent.", visual_keywords=["loki", "punishment"]),
        Scene(narration="Even Jormungandr, the great sea serpent, stirred in the depths.", visual_keywords=["ocean", "eel"]),
        Scene(narration="Ragnarok, the end of all things, was coming.", visual_keywords=["ragnarok", "apocalypse"]),
    ]
    assert pi._dominant_subject(scenes) is None


def test_dominant_subject_still_wins_when_title_names_it():
    scenes = [
        Scene(narration="It has three hearts.", visual_keywords=["heart"]),
        Scene(narration="Its blood is blue.", visual_keywords=["blood"]),
    ]
    assert pi._dominant_subject(scenes, extra_text="Why Octopuses Have Blue Blood") == "octopus"


def test_mistletoe_scene_gets_forest_setting_not_default():
    scene = Scene(narration="Loki alone knew mistletoe could kill him.", visual_keywords=["mistletoe"])
    assert pi._setting_for_scene(scene) == "forest"


def test_octopus_scene_renders_water_and_subject(tmp_path):
    scene = Scene(narration="Its blood is blue.", visual_keywords=["blood"])
    path = pi.generate_scene_image(scene, 0, _config(), tmp_path, subject_fallback="octopus")
    with Image.open(path) as img:
        # Lower-centre pixel should be water-blue or subject, not white sky.
        w, h = img.size
        assert img.getpixel((int(w * 0.05), int(h * 0.7))) != (255, 255, 255)


def test_scene_clip_is_a_valid_video_of_the_right_length(tmp_path):
    import subprocess
    scene = Scene(narration="The octopus drifts.", visual_keywords=["octopus"])
    clip = pi.generate_scene_clip(scene, 0, _config(), tmp_path, duration=2.0, subject_fallback="octopus")
    assert clip.exists() and clip.suffix == ".mp4"
    dur = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(clip)],
        capture_output=True, text=True).stdout.strip()
    assert abs(float(dur) - 2.0) < 0.3


def test_scene_clip_background_actually_pans_not_a_frozen_still(tmp_path):
    # Regression test: a scene with no subject at all used to render as a
    # single frozen frame for its whole duration (the Ken Burns pan/zoom is
    # the fix for that) - assert the background genuinely moves, not just
    # that a video file of the right length exists.
    import subprocess
    from PIL import ImageChops

    scene = Scene(narration="The city stood in silence.", visual_keywords=["city"])
    clip = pi.generate_scene_clip(scene, 3, _config(), tmp_path, duration=3.0)

    first = tmp_path / "first.png"
    last = tmp_path / "last.png"
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(clip), "-vf", "select=eq(n\\,0)", "-vframes", "1", str(first)],
        capture_output=True, check=True,
    )
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(clip), "-vf", "select=eq(n\\,60)", "-vframes", "1", str(last)],
        capture_output=True, check=True,
    )
    with Image.open(first) as a, Image.open(last) as b:
        diff = ImageChops.difference(a.convert("RGB"), b.convert("RGB"))
    assert diff.getbbox() is not None, "background frame is identical at t=0 and t=2s - pan/zoom isn't happening"


def test_generate_all_clips_one_per_scene(tmp_path):
    scenes = [
        Scene(narration="A soldier marches.", visual_keywords=["soldier"]),
        Scene(narration="The octopus swims.", visual_keywords=["octopus"]),
    ]
    clips = pi.generate_all_clips(scenes, [1.5, 1.5], _config(), tmp_path)
    assert len(clips) == 2 and all(c.exists() for c in clips)


def test_fight_scene_detected_by_keyword():
    scene = Scene(narration="The two knights fought outside the gates.", visual_keywords=["sword fight"])
    assert pi._is_fight_scene(scene)
    calm = Scene(narration="The farmer tended his field.", visual_keywords=["farm"])
    assert not pi._is_fight_scene(calm)


def test_crowd_scene_detected_by_keyword():
    scene = Scene(narration="The court murmured as the king entered.", visual_keywords=["court"])
    assert pi._is_crowd_scene(scene)
    calm = Scene(narration="The farmer tended his field alone.", visual_keywords=["farm"])
    assert not pi._is_crowd_scene(calm)


def test_crowd_scene_covers_everyday_group_words_not_just_royal_court():
    # "always only 1 person" was the reported complaint - crowd detection
    # shouldn't only fire on throne-room vocabulary.
    scene = Scene(narration="His family gathered around him at the end.", visual_keywords=["family"])
    assert pi._is_crowd_scene(scene)


def test_fight_scene_renders_two_figures_not_one(tmp_path):
    # Regression guard for "show more than one stick if needed": a fight
    # scene must not fall through to the single centred-character
    # composition - its painted content should span both fighters, not
    # cluster in the width of a single figure.
    from PIL import ImageChops, ImageDraw

    scene = Scene(narration="The two soldiers fought in the ruins.", visual_keywords=["sword fight", "ruins"])
    rng = pi.random.Random(0)
    _base, paint, _motion, _comp = pi._compose_scene(rng, scene, _config(), subject=None)
    size = tuple(_config().video.resolution_longform)
    img = Image.new("RGB", size, (255, 255, 255))
    paint(ImageDraw.Draw(img), phase=math.pi / 2)
    diff = ImageChops.difference(img, Image.new("RGB", size, (255, 255, 255)))
    bbox = diff.getbbox()
    assert bbox is not None
    left, _top, right, _bottom = bbox
    assert (right - left) > size[0] * 0.25, "painted content is too narrow to be two separate figures"


def test_crowd_scene_adds_background_figures(tmp_path):
    scene = Scene(narration="The court murmured as the king entered the hall.", visual_keywords=["court", "king"])
    rng = pi.random.Random(0)
    _base, paint, _motion, _comp = pi._compose_scene(rng, scene, _config(), subject=None)
    img = Image.new("RGB", tuple(_config().video.resolution_longform), (255, 255, 255))
    from PIL import ImageDraw
    paint(ImageDraw.Draw(img), phase=0.0)
    # A crowd scene should paint content off to the sides (background
    # figures), not just the single centred focal character.
    w = img.size[0]
    pixels = img.load()
    side_has_content = any(pixels[x, 850] != (255, 255, 255) for x in range(0, w // 5))
    assert side_has_content


def test_headwear_drawers_never_leave_a_gap_above_the_head():
    # Regression test: _flat_cap's bounding box once left its flat edge
    # above the head's top edge entirely, so the cap floated free instead
    # of resting on the head (same class of bug _helmet used to have).
    # All headwear drawers should overlap the head circle's top half.
    r = 95.0
    head_cy = 300.0
    head_top = head_cy - r
    for name, drawer in pi._HEADWEAR_DRAWERS.items():
        from PIL import ImageDraw
        img = Image.new("RGB", (600, 600), (255, 255, 255))
        d = ImageDraw.Draw(img)
        drawer(d, 300, head_cy, r)
        # Any non-white pixel at or below the head's top edge means the
        # headwear reaches down to (or overlaps) the head instead of
        # floating entirely above it.
        row = int(head_top)
        pixels = img.load()
        touches_head = any(pixels[x, row] != (255, 255, 255) for x in range(600))
        assert touches_head, f"{name} headwear floats above the head with a visible gap"


def test_dramatic_beat_detection():
    hook = Scene(narration="A quiet morning.", visual_keywords=[], role="hook")
    shocked = Scene(narration="The bridge collapsed without warning.", visual_keywords=[], role="build")
    plain = Scene(narration="Trade along the coast grew steadily.", visual_keywords=[], role="build")
    fight = Scene(narration="The two soldiers fought in the mud.", visual_keywords=[], role="build")
    assert pi._is_dramatic_beat(hook) is True
    assert pi._is_dramatic_beat(shocked) is True
    assert pi._is_dramatic_beat(fight) is True
    assert pi._is_dramatic_beat(plain) is False


def test_hook_scene_flashes_in_from_white_but_plain_scene_does_not(tmp_path):
    import numpy as np

    hook = Scene(narration="A city vanished overnight.", visual_keywords=["city"], role="hook")
    plain = Scene(narration="Trade along the coast grew steadily.", visual_keywords=["coast"], role="build")

    hook_clip = pi.generate_scene_clip(hook, 0, _config(), tmp_path, duration=2.0)
    plain_clip = pi.generate_scene_clip(plain, 1, _config(), tmp_path, duration=2.0)

    def first_frame_brightness(clip_path):
        frame_path = tmp_path / f"{clip_path.stem}_frame0.png"
        import subprocess
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(clip_path), "-vf", "select=eq(n\\,0)", "-vframes", "1", str(frame_path)],
            capture_output=True, check=True,
        )
        with Image.open(frame_path) as img:
            return np.array(img.convert("L")).mean()

    hook_brightness = first_frame_brightness(hook_clip)
    plain_brightness = first_frame_brightness(plain_clip)
    assert hook_brightness > plain_brightness, "hook scene's first frame should be flashed toward white"
    assert hook_brightness > 240, "hook scene's very first frame should be almost entirely white"


def test_dramatic_beat_pans_faster_than_a_plain_scene(tmp_path):
    import subprocess
    import numpy as np

    hook = Scene(narration="A city vanished overnight.", visual_keywords=["city"], role="hook")
    plain = Scene(narration="Trade along the coast grew steadily.", visual_keywords=["coast"], role="build")

    def motion_energy(scene, index):
        clip = pi.generate_scene_clip(scene, index, _config(), tmp_path, duration=2.0)
        f0 = tmp_path / f"{clip.stem}_m0.png"
        f1 = tmp_path / f"{clip.stem}_m1.png"
        subprocess.run(["ffmpeg", "-y", "-i", str(clip), "-vf", "select=eq(n\\,5)", "-vframes", "1", str(f0)],
                        capture_output=True, check=True)
        subprocess.run(["ffmpeg", "-y", "-i", str(clip), "-vf", "select=eq(n\\,25)", "-vframes", "1", str(f1)],
                        capture_output=True, check=True)
        with Image.open(f0) as a, Image.open(f1) as b:
            arr_a = np.array(a.convert("L"), dtype=float)
            arr_b = np.array(b.convert("L"), dtype=float)
        return np.abs(arr_a - arr_b).mean()

    assert motion_energy(hook, 0) > motion_energy(plain, 1)


def test_character_not_flying(tmp_path):
    """Character x-position should stay within reasonable bounds (not fly across screen)."""
    from PIL import ImageChops, ImageDraw
    config = _config()
    w, h = config.video.resolution
    
    scene = Scene(narration="A farmer walked through the fields.", visual_keywords=["field"], role="build")
    rng = pi.random.Random(0)
    base, paint, motion, comp = pi._compose_scene(rng, scene, config, subject=None)
    
    # Check motion parameters: ax should be 0 for non-aquatic
    ax, ay, px, py = motion
    assert ax == 0.0, f"Non-aquatic character has horizontal motion ax={ax} — will fly across screen"
    assert ay > 0, "Character should have vertical bob"
    
    # Render and verify character stays in frame
    img = Image.new("RGB", (w, h), (255, 255, 255))
    paint(ImageDraw.Draw(img))
    diff = ImageChops.difference(img, Image.new("RGB", (w, h), (255, 255, 255)))
    bbox = diff.getbbox()
    assert bbox is not None
    left, top, right, bottom = bbox
    # Character should be roughly centered horizontally (not at edge)
    assert left > w * 0.15, "Character too far left"
    assert right < w * 0.85, "Character too far right"


def test_historical_character_selection():
    """Archetype resolution matches expected keywords."""
    # Greek
    assert pi._resolve_character_archetype(Scene(narration="Odysseus sailed home.", visual_keywords=["odysseus"], role="hook")) == "odysseus"
    assert pi._resolve_character_archetype(Scene(narration="The Trojan War began.", visual_keywords=["trojan"], role="build")) == "odysseus"
    # Knight
    assert pi._resolve_character_archetype(Scene(narration="A knight drew his sword.", visual_keywords=["knight"], role="hook")) == "knight"
    # Roman
    assert pi._resolve_character_archetype(Scene(narration="The centurion ordered the legion.", visual_keywords=["centurion"], role="build")) == "centurion"
    # Viking
    assert pi._resolve_character_archetype(Scene(narration="The viking raided the coast.", visual_keywords=["viking"], role="build")) == "viking"
    # Default
    assert pi._resolve_character_archetype(Scene(narration="A merchant traded spices.", visual_keywords=["trade"], role="build")) == "scholar"


def test_battle_scene_supporting_cast(tmp_path):
    """Battle scenes should render 10+ background figures."""
    from PIL import ImageChops, ImageDraw
    config = _config()
    w, h = config.video.resolution
    
    scene = Scene(narration="Ten thousand soldiers clashed on the battlefield.", 
                  visual_keywords=["battle", "army", "ten thousand"], role="build")
    rng = pi.random.Random(0)
    base, paint, motion, comp = pi._compose_scene(rng, scene, config, subject=None)
    
    # Should have battle composition
    assert pi._is_battle_scene_public(Scene(narration="", visual_keywords=["battle"], role="build"))
    
    # Render and count distinct figures (rough check via color diversity)
    img = Image.new("RGB", (w, h), (255, 255, 255))
    paint(ImageDraw.Draw(img))
    # Count non-white pixels in lower half (where soldiers stand)
    pixels = img.load()
    colors = set()
    for y in range(h // 2, h):
        for x in range(0, w, 20):
            c = pixels[x, y]
            if c != (255, 255, 255):
                # Quantize to reduce noise
                colors.add((c[0]//20, c[1]//20, c[2]//20))
    # Should have many distinct colors from multiple soldiers
    assert len(colors) > 8, f"Only {len(colors)} color clusters — expected many soldiers"


def test_war_ambience_generated(tmp_path):
    """War ambience track should be created for battle scenes."""
    from youtube_automation import sound_effects
    from youtube_automation.tts import SceneAudio
    
    scenes = [Scene(narration="The army marched to war.", visual_keywords=["war", "army"], role="build")]
    audio = [SceneAudio(scene_index=0, audio_path=__file__, duration=10.0, cues=[])]
    
    path = sound_effects.build_ambience_track(scenes, audio, 0.0, 0.0, tmp_path)
    assert path is not None
    assert path.exists()
    assert path.stat().st_size > 1000  # non-trivial audio


def test_scene_duration_5_15s():
    """Script writer should target 5-15s per scene."""
    from youtube_automation.config import PipelineConfig, VideoConfig
    cfg = PipelineConfig.load()
    assert cfg.video.min_scene_duration == 5
    assert cfg.video.max_scene_duration == 15
    assert cfg.video.target_scene_duration == 8


def test_tts_role_passed():
    """Scene role should be passed to TTS synthesizer."""
    import inspect
    from youtube_automation import tts
    sig = inspect.signature(tts._synthesize_one)
    assert "role" in sig.parameters
    assert sig.parameters["role"].default == "build"


def test_ssml_pitch_format():
    """Pitch values should use semitones (st) not Hz."""
    from youtube_automation.tts import _ROLE_PROSODY
    for role, prosody in _ROLE_PROSODY.items():
        pitch = prosody["pitch"]
        assert pitch.endswith("st") or pitch == "+0st", f"Role {role} pitch '{pitch}' not in semitones"
