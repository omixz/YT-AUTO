with open(r'C:\Users\Omarn\OneDrive\Documents\Default Project\YT-AUTO\youtube_automation\tts.py', 'rb') as f:
    content = f.read()

idx = content.find(b'def synthesize_script')
doc_idx = content.find(b'"""Synthesize', idx)
end_idx = content.find(b'"""', doc_idx + 3)
docstring = content[doc_idx:end_idx+3]
print('Docstring:', repr(docstring))

# Check for any non-ASCII
for i, b in enumerate(docstring):
    if b >= 128:
        print(f'Non-ASCII at {i}: {hex(b)}')